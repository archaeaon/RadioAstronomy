
void SPI_wait_clk()
{	
	__asm
	nop
	__endasm;
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	nop*/
/*	__endasm;*/
}
