#!/bin/sh

rm *.rel
rm *.hex
rm *.ihx
rm *.rst
rm *.sym
rm *.asm
rm *.lk
rm *.lst
rm *.map
rm *.mem

