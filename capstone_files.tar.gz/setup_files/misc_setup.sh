#!/bin/bash
###### IMPORTANT: Run this script as a non-root user!!! ######
sudo apt update
sudo apt upgrade
sudo apt install neofetch
sudo apt install gnome-terminal
sudo apt install python-pip3
sudo apt install g++
pip3 install matplotlib

echo -e "\nInstalling SoapySDR API...\n"
python3 pyLMS7002Soapy/setup.py install
echo -e "\nSoapySDR API installed\!\n"

echo -e "\nChanging hostname from ubuntu to raspberrypi...\n"
sudo echo "raspberrypi" > /etc/hostname
echo -e "\nHostname changed! Will take effect on next reboot.\n"

# shortcuts for enabling either GUI or terminal boot mode (the Ctrl+Alt+F# method doesn't seem to work too well)
echo -e "\nCreating aliases in ~/.bash_aliases...\n"
echo "alias set-boot-to-terminal='sudo systemctl set-default multi-user.target'" >> ~/.bash_aliases
echo "alias set-boot-to-gui='sudo systemctl set-default graphical.target'" >> ~/.bash_aliases
source ~/.bash_aliases
