#!/bin/bash
###### IMPORTANT: Run this script as root from created user!!! ######

echo -e "\nRemoving default user...\n"
bash rm_default_user.sh
echo -e "\nDefault user removed\!\n"

echo -e "\nSetting up SSD to automount...\n"
bash ssd_automount_setup.sh
echo -e "\nSSD successfully set to automount\!\n"

echo -e "\nSetting up Wi-Fi connection...\n"
bash setup_wifi.sh
echo -e "\nWi-Fi connection successful\! You can test using 'apt update'. You may need to try it more than once."

echo -e "\nSetting up GPS...\n"
bash setup_gps.sh
echo -e "\nGPS setup successful\!\n"

echo -e "\nInstalling LimeSuite...\n"
bash limesuite_install.sh
echo -e "\nLimeSuite successfully installed\!\n"

echo -e "\nUpdating LimeSuite udev-rules...\n"
bash update_limesuite_rules.sh
echo -e "\nLimeSuite udev-rules updated successfully\!\n"
