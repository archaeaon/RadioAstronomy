sudo add-apt-repository -y ppa:myriadrf/drivers
sudo apt update
sudo apt upgrade
sudo apt install limesuite liblimesuite-dev limesuite-udev limesuite-images
sudo apt install soapysdr-tools soapysdr-module-lms7

