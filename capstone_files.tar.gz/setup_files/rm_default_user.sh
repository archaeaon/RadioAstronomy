#!/bin/bash
###### NOTE: Run this script as root from the created user!!! ######

default_username=ubuntu

echo "Removing default user $default_username..."
deluser "$default_username"
rm -r /home/"$default_username"

echo "Default user $default_username has been removed."
