#!/bin/bash
###### NOTE: Run this script as root!!! ######

filename=`ls /etc/netplan`
filepath=/etc/netplan/"$filename"
wifi=`ls /sys/class/net | grep 'wl'`

echo "    wifis:" >> "$filepath"
echo "        $wifi:" >> "$filepath"
echo "            optional: true" >> "$filepath"
echo "            access-points:" >> "$filepath"
echo "                \"SSID-NAME-HERE\":" >> "$filepath"	# TODO: Replace SSID-NAME-HERE with actual wifi name
echo "                    password: \"PASSWORD-HERE\"" >> "$filepath"	# TODO: Replace PASSWORD-HERE with actual wifi password
echo "            dhcp4: true" >> "$filepath"

netplan apply
