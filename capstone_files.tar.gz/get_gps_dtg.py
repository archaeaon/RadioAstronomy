from gps import *

def get_gps_time (gps):
    nx = gpsd.next()
    
    if (nx['class'] == 'TPV'):
        _gps_dtg = getattr(nx, 'time', "Unknown")
    
        if (_gps_dtg != "Unknown"):
            #print("GPS time: %s" %(_gps_dtg))
            return _gps_dtg
        
        else:
            return None

gpsd = gps(mode=WATCH_ENABLE|WATCH_NEWSTYLE)
gps_dtg = None

while (gps_dtg == None):
    gps_dtg = get_gps_time(gpsd) # Don't sleep between loops here like in the example code.
                                 # The delay will result in recording the wrong time.

date = gps_dtg[:10]
time = gps_dtg[11:]
print("%s %s" %(date, time)) # this is necessary for Bash to be able to convert it to its standard dtg format