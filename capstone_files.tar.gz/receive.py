#!/usr/bin/python
#GPU power spectrum
import array, os
import numpy as np
import math, struct
import time

#setup radio
import SoapySDR
from SoapySDR import *
args = dict(driver="lime")
sdr = SoapySDR.Device(args)
sdr.setSampleRate(SOAPY_SDR_RX, 0, 6e6)
sdr.setSampleRate(SOAPY_SDR_RX, 1, 6e6)
sdr.setBandwidth(SOAPY_SDR_RX, 0, 4.25e6)
sdr.setBandwidth(SOAPY_SDR_RX, 1, 4.25e6)
sdr.setFrequency(SOAPY_SDR_RX, 0, 611.0e6)
sdr.setFrequency(SOAPY_SDR_RX, 1, 611.0e6)
sdr.setAntenna(SOAPY_SDR_RX,0,"LNAW")
sdr.setAntenna(SOAPY_SDR_RX,1,"LNAW")

sdr.setGain(SOAPY_SDR_RX,0,"TIA",5.0)
sdr.setGain(SOAPY_SDR_RX,0,"PGA",5.0)
sdr.setGain(SOAPY_SDR_RX,0,"LNA",35.0)

sdr.setGain(SOAPY_SDR_RX,1,"TIA",5.0)
sdr.setGain(SOAPY_SDR_RX,1,"PGA",5.0)
sdr.setGain(SOAPY_SDR_RX,1,"LNA",35.0)

rxStream = sdr.setupStream(SOAPY_SDR_RX, SOAPY_SDR_CF32, [0,1])
sdr.activateStream(rxStream)

fa = os.open("./fifoA", os.O_WRONLY)
fb = os.open("./fifoB", os.O_WRONLY)


ea0 = np.array([0]*4000, np.complex64)
ea1 = np.array([0]*4000, np.complex64)
while True:
    sr = sdr.readStream(rxStream, [ea0,ea1], len(ea0))
    b0 = np.getbuffer(ea0)
    b1 = np.getbuffer(ea1)
    os.write(fa, b0)
    os.write(fb, b1)
